Hello!

I know my version is far from identical to original but I tried to focus more on implementing what I can remeber from precourse and just practice what we have covered so far.
Two things in particular im not content with myself:

- Couldnt manage to make a dropdown menu in the navbar to work, though tried different approaches and spent some time on it and still didnt get why is it not working..

- I assume my CSS is a disaster but so far cant help it and do what I can :) Looking forward to learn and improve structure and ways to manage it with JavaScript.

